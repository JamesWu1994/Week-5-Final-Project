package com.asset.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.asset.app.exception.ResourceNotFoundException;
import com.asset.app.model.User;
import com.asset.app.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService
{
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<User> getUsers() 
	{
		return userRepository.findAll();
	}

	@Override
	public User getUserById(Integer id) 
	{
		return userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
	}
	
	@Override
	public User saveUser(User user) 
	{
		return userRepository.saveAndFlush(user);
	}

	@Override
	public User updateUser(Integer id, User user) 
	{
		User oldUser = getUserById(id);
		
		if(!ObjectUtils.isEmpty(oldUser) && !ObjectUtils.isEmpty(user))
		{
			user.setId(id);
			return saveUser(user);
		}			
		return null;
	}

	@Override
	public void deleteUser(Integer id)
	{
		if(userRepository.existsById(id))
			userRepository.deleteById(id);
		else
			throw new ResourceNotFoundException("User", "id", id);
	}
}
