package com.asset.app.service;

import java.util.List;

import com.asset.app.model.Trades;

public interface TradesService 
{
	public List<Trades> getTrades();

	public Trades getTradesById(Integer id);

	public Trades saveTrades(Trades trades);

	public Trades updateTrades(Integer id, Trades trades);

	public void deleteTrades(Integer id);
}
