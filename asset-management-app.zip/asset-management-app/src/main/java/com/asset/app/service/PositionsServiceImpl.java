package com.asset.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.asset.app.exception.ResourceNotFoundException;
import com.asset.app.model.Positions;
import com.asset.app.repository.PositionsRepository;

@Service
public class PositionsServiceImpl implements PositionsService 
{
	@Autowired
	private PositionsRepository positionsRepository;
	
	@Override
	public List<Positions> getPositions() 
	{
		return positionsRepository.findAll();
	}

	@Override
	public Positions getPositionsById(Integer id) 
	{
		return positionsRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Positions", "id", id));
	}
	
	@Override
	public Positions savePositions(Positions user) 
	{
		return positionsRepository.saveAndFlush(user);
	}

	@Override
	public Positions updatePositions(Integer id, Positions user) 
	{
		Positions oldPositions = getPositionsById(id);
		
		if(!ObjectUtils.isEmpty(oldPositions) && !ObjectUtils.isEmpty(user))
		{
			user.setId(id);
			return savePositions(user);
		}			
		return null;
	}

	@Override
	public void deletePositions(Integer id)
	{
		if(positionsRepository.existsById(id))
			positionsRepository.deleteById(id);
		else
			throw new ResourceNotFoundException("Positions", "id", id);
	}
}
