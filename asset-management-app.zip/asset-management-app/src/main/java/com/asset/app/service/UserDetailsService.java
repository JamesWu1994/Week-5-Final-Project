package com.asset.app.service;

import java.util.List;

import com.asset.app.model.UserDetails;

public interface UserDetailsService 
{
	public List<UserDetails> getUserDetails();

	public UserDetails getUserDetailsById(Integer id);

	public UserDetails saveUserDetails(UserDetails userDetails);

	public UserDetails updateUserDetails(Integer id, UserDetails userDetails);

	public void deleteUserDetails(Integer id);
}
