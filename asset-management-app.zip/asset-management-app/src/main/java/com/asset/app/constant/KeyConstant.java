package com.asset.app.constant;

public class KeyConstant 
{
	public static final String NOT_FOUND = "Not Found";
	public static final String BAD_DATA = "Bad Data";
	public static final String SERVER_ERROR = "Server Error";
	  
	public static final String MESSAGE_OK = "OK";
	public static final String MESSAGE_CREATED = "CREATED";
	public static final String MESSAGE_NO_CONTENT = "NO CONTENT";
	public static final String MESSAGE_BAD_REQUEST = "BAD REQUEST";
	public static final String MESSAGE_NOT_FOUND = "NOT FOUND";	  
	  
	public static final int STATUS_CODE_200 = 200;
	public static final int STATUS_CODE_201 = 201;
	public static final int STATUS_CODE_204 = 204;
	public static final int STATUS_CODE_400 = 400;
	public static final int STATUS_CODE_404 = 404;
	  
	public static final String UNEXPECTED_ERROR = "Unexpected Server Error";
	public static final String VALIDATION_ERROR = "Validation Error";
	  
	public static final String CONTEXT_USERS = "/users";
	public static final String CONTEXT_ASSETS = "/assets";
	public static final String CONTEXT_USER_DETAILS = "/user-details";
	public static final String CONTEXT_TRADES = "/trades";
	public static final String CONTEXT_POSITIONS = "/positions";
}
