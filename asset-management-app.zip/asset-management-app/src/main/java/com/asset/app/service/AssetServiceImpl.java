package com.asset.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.asset.app.exception.ResourceNotFoundException;
import com.asset.app.model.Asset;
import com.asset.app.repository.AssetRepository;

@Service
public class AssetServiceImpl implements AssetService
{
	@Autowired
	private AssetRepository assetRepository;
	
	@Override
	public List<Asset> getAssets() 
	{
		return assetRepository.findAll();
	}

	@Override
	public Asset getAssetById(Integer id) 
	{
		return assetRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Asset", "id", id));
	}
	
	@Override
	public Asset saveAsset(Asset asset) 
	{
		return assetRepository.saveAndFlush(asset);
	}

	@Override
	public Asset updateAsset(Integer id, Asset asset) 
	{
		Asset oldAsset = getAssetById(id);
		
		if(!ObjectUtils.isEmpty(oldAsset) && !ObjectUtils.isEmpty(asset))
		{
			asset.setId(id);
			return saveAsset(asset);
		}			
		return null;
	}

	@Override
	public void deleteAsset(Integer id)
	{
		if(assetRepository.existsById(id))
			assetRepository.deleteById(id);
		else
			throw new ResourceNotFoundException("Asset", "id", id);
	}
}
