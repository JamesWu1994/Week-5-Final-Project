package com.asset.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.asset.app.model.User;
import com.asset.app.service.UserService;

import static com.asset.app.constant.KeyConstant.*;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = CONTEXT_USERS, produces = "application/json")
public class UserController
{
	@Autowired
	private UserService userService;
	
//-------------------------------------------------------------GET ALL USERS-----------------------------------------------------
		
	@GetMapping()
	@ApiOperation("Get all Users")
	@ApiResponses(value = {
			@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = User.class)
	})
	public ResponseEntity<List<User>> getUsers()
	{
			return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);		
	}
	
//-------------------------------------------------------------GET USER BY ID-----------------------------------------------------
	
	@GetMapping("/{id}")
	@ApiOperation("Get a User By Id")
	@ApiResponses(value = {
		@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = User.class),
		@ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	})
	public ResponseEntity<User> getUserById(@PathVariable("id") Integer id)
	{
		return new ResponseEntity<>(userService.getUserById(id), HttpStatus.OK);
	}
		
//-------------------------------------------------------------SAVE USER INFO-----------------------------------------------------
	
	@PostMapping()
	@ApiOperation("Add a new User")
	@ApiResponses(value = {
	      @ApiResponse(code = STATUS_CODE_201, message = MESSAGE_CREATED, response = User.class),
	      @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<User> saveUser(@RequestBody User user)
	{
	   return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
	}
	
//-------------------------------------------------------------UPDATE USER INFO-----------------------------------------------------
	
	@PutMapping("/{id}")
	@ApiOperation("Update a User by Id")
	@ApiResponses(value = {
	    @ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = User.class),
	    @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND),
	    @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<User> updateUser(@PathVariable("id") Integer id, @RequestBody User user)
	{	    
		return new ResponseEntity<>(userService.updateUser(id, user), HttpStatus.OK);
	}
	
//-------------------------------------------------------------DELETE USER---------------------------------------------------------
	
	 @DeleteMapping("/{id}")
	 @ResponseStatus(HttpStatus.NO_CONTENT)
	 @ApiOperation("Deletes a User by Id")
	 @ApiResponses(value = {
	     @ApiResponse(code = STATUS_CODE_204, message = MESSAGE_NO_CONTENT),
	     @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	  })
	 public void deleteUser(@PathVariable("id") Integer id) 
	 {
		 userService.deleteUser(id);
	 }
	
//---------------------------------------------------------------END-------------------------------------------------------------	
	
}
