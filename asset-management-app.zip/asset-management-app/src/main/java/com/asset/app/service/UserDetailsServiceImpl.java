package com.asset.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.asset.app.exception.ResourceNotFoundException;
import com.asset.app.model.UserDetails;
import com.asset.app.repository.UserDetailsRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService 
{
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	
	@Override
	public List<UserDetails> getUserDetails() 
	{
		return userDetailsRepository.findAll();
	}

	@Override
	public UserDetails getUserDetailsById(Integer id) 
	{
		return userDetailsRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("UserDetails", "id", id));
	}
	
	@Override
	public UserDetails saveUserDetails(UserDetails userDetails) 
	{
		return userDetailsRepository.saveAndFlush(userDetails);
	}

	@Override
	public UserDetails updateUserDetails(Integer id, UserDetails userDetails) 
	{
		UserDetails oldUserDetails = getUserDetailsById(id);
		
		if(!ObjectUtils.isEmpty(oldUserDetails) && !ObjectUtils.isEmpty(userDetails))
		{
			userDetails.setId(id);
			return saveUserDetails(userDetails);
		}			
		return null;
	}

	@Override
	public void deleteUserDetails(Integer id)
	{
		if(userDetailsRepository.existsById(id))
			userDetailsRepository.deleteById(id);
		else
			throw new ResourceNotFoundException("UserDetails", "id", id);
	}
}
