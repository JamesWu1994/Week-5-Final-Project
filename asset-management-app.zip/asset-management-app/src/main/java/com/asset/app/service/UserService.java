package com.asset.app.service;

import java.util.List;

import com.asset.app.model.User;

public interface UserService 
{
	public List<User> getUsers();

	public User getUserById(Integer id);

	public User saveUser(User user);

	public User updateUser(Integer id, User user);

	public void deleteUser(Integer id);
}
