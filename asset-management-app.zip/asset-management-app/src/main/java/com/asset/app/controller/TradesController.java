package com.asset.app.controller;

import static com.asset.app.constant.KeyConstant.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.asset.app.model.Trades;
import com.asset.app.service.TradesService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = CONTEXT_TRADES, produces = "application/json")
public class TradesController 
{
	@Autowired
	private TradesService tradesService;
	
//-------------------------------------------------------------GET ALL TRADES-----------------------------------------------------
		
	@GetMapping()
	@ApiOperation("Get all Tradess")
	@ApiResponses(value = {
			@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Trades.class)
	})
	public ResponseEntity<List<Trades>> getTradess()
	{
			return new ResponseEntity<>(tradesService.getTrades(), HttpStatus.OK);		
	}
	
//-------------------------------------------------------------GET USER BY ID-----------------------------------------------------
	
	@GetMapping("/{id}")
	@ApiOperation("Get a Trades By Id")
	@ApiResponses(value = {
		@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Trades.class),
		@ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	})
	public ResponseEntity<Trades> getTradesById(@PathVariable("id") Integer id)
	{
		return new ResponseEntity<>(tradesService.getTradesById(id), HttpStatus.OK);
	}
		
//-------------------------------------------------------------SAVE USER INFO-----------------------------------------------------
	
	@PostMapping()
	@ApiOperation("Add a new Trades")
	@ApiResponses(value = {
	      @ApiResponse(code = STATUS_CODE_201, message = MESSAGE_CREATED, response = Trades.class),
	      @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<Trades> saveTrades(@RequestBody Trades trades)
	{
	   return new ResponseEntity<>(tradesService.saveTrades(trades), HttpStatus.CREATED);
	}
	
//-------------------------------------------------------------UPDATE USER INFO-----------------------------------------------------
	
	@PutMapping("/{id}")
	@ApiOperation("Update a Trades by Id")
	@ApiResponses(value = {
	    @ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Trades.class),
	    @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND),
	    @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<Trades> updateTrades(@PathVariable("id") Integer id, @RequestBody Trades trades)
	{	    
		return new ResponseEntity<>(tradesService.updateTrades(id, trades), HttpStatus.OK);
	}
	
//-------------------------------------------------------------DELETE USER---------------------------------------------------------
	
	 @DeleteMapping("/{id}")
	 @ResponseStatus(HttpStatus.NO_CONTENT)
	 @ApiOperation("Deletes a Trades by Id")
	 @ApiResponses(value = {
	     @ApiResponse(code = STATUS_CODE_204, message = MESSAGE_NO_CONTENT),
	     @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	  })
	 public void deleteTrades(@PathVariable("id") Integer id) 
	 {
		 tradesService.deleteTrades(id);
	 }
	
//---------------------------------------------------------------END-------------------------------------------------------------	
}
