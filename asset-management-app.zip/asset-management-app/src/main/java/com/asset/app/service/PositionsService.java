package com.asset.app.service;

import java.util.List;

import com.asset.app.model.Positions;

public interface PositionsService 
{
	public List<Positions> getPositions();

	public Positions getPositionsById(Integer id);

	public Positions savePositions(Positions position);

	public Positions updatePositions(Integer id, Positions position);

	public void deletePositions(Integer id);
}
