package com.asset.app.controller;

import static com.asset.app.constant.KeyConstant.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.asset.app.model.Asset;
import com.asset.app.service.AssetService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = CONTEXT_ASSETS, produces = "application/json")
public class AssetController 
{
	@Autowired
	private AssetService assetService;
	
//-------------------------------------------------------------GET ALL ASSETS-----------------------------------------------------
		
	@GetMapping()
	@ApiOperation("Get all Assets")
	@ApiResponses(value = {
			@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Asset.class)
	})
	public ResponseEntity<List<Asset>> getAssets()
	{
			return new ResponseEntity<>(assetService.getAssets(), HttpStatus.OK);		
	}
	
//-------------------------------------------------------------GET USER BY ID-----------------------------------------------------
	
	@GetMapping("/{id}")
	@ApiOperation("Get a Asset By Id")
	@ApiResponses(value = {
		@ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Asset.class),
		@ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	})
	public ResponseEntity<Asset> getAssetById(@PathVariable("id") Integer id)
	{
		return new ResponseEntity<>(assetService.getAssetById(id), HttpStatus.OK);
	}
		
//-------------------------------------------------------------SAVE USER INFO-----------------------------------------------------
	
	@PostMapping()
	@ApiOperation("Add a new Asset")
	@ApiResponses(value = {
	      @ApiResponse(code = STATUS_CODE_201, message = MESSAGE_CREATED, response = Asset.class),
	      @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<Asset> saveAsset(@RequestBody Asset asset)
	{
	   return new ResponseEntity<>(assetService.saveAsset(asset), HttpStatus.CREATED);
	}
	
//-------------------------------------------------------------UPDATE USER INFO-----------------------------------------------------
	
	@PutMapping("/{id}")
	@ApiOperation("Update a Asset by Id")
	@ApiResponses(value = {
	    @ApiResponse(code = STATUS_CODE_200, message = MESSAGE_OK, response = Asset.class),
	    @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND),
	    @ApiResponse(code = STATUS_CODE_400, message = MESSAGE_BAD_REQUEST)
	})
	public ResponseEntity<Asset> updateAsset(@PathVariable("id") Integer id, @RequestBody Asset asset)
	{	    
		return new ResponseEntity<>(assetService.updateAsset(id, asset), HttpStatus.OK);
	}
	
//-------------------------------------------------------------DELETE USER---------------------------------------------------------
	
	 @DeleteMapping("/{id}")
	 @ResponseStatus(HttpStatus.NO_CONTENT)
	 @ApiOperation("Deletes a Asset by Id")
	 @ApiResponses(value = {
	     @ApiResponse(code = STATUS_CODE_204, message = MESSAGE_NO_CONTENT),
	     @ApiResponse(code = STATUS_CODE_404, message = MESSAGE_NOT_FOUND)
	  })
	 public void deleteAsset(@PathVariable("id") Integer id) 
	 {
		 assetService.deleteAsset(id);
	 }
	
//---------------------------------------------------------------END-------------------------------------------------------------	
}
