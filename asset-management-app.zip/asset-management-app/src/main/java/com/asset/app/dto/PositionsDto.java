package com.asset.app.dto;

public class PositionsDto 
{

}
