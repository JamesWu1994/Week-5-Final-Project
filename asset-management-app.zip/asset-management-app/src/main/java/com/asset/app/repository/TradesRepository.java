package com.asset.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.asset.app.model.Trades;

@Service
public interface TradesRepository extends JpaRepository<Trades, Integer>
{

}
