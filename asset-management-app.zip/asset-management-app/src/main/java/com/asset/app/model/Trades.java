package com.asset.app.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table( name="trades")
@Data @NoArgsConstructor @AllArgsConstructor
public class Trades 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private Integer id;

	private String assetSymbol;

	private Integer shares;

	private Double assetPrice;

	private Double totalAmount;

	private String orderType;
	
	@ManyToMany(mappedBy = "trades", fetch = FetchType.LAZY)
    private Set<User> users = new HashSet<>();
}
