package com.asset.app.service;

import java.util.List;

import com.asset.app.model.Asset;

public interface AssetService 
{
	public List<Asset> getAssets();

	public Asset getAssetById(Integer id);

	public Asset saveAsset(Asset asset);

	public Asset updateAsset(Integer id, Asset asset);

	public void deleteAsset(Integer id);
}
