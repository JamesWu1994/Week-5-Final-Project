package com.asset.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.asset.app.exception.ResourceNotFoundException;
import com.asset.app.model.Trades;
import com.asset.app.repository.TradesRepository;

@Service
public class TradesServiceImpl implements TradesService
{
	@Autowired
	private TradesRepository tradesRepository;
	
	@Override
	public List<Trades> getTrades() 
	{
		return tradesRepository.findAll();
	}

	@Override
	public Trades getTradesById(Integer id) 
	{
		return tradesRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Trades", "id", id));
	}
	
	@Override
	public Trades saveTrades(Trades user) 
	{
		return tradesRepository.saveAndFlush(user);
	}

	@Override
	public Trades updateTrades(Integer id, Trades user) 
	{
		Trades oldTrades = getTradesById(id);
		
		if(!ObjectUtils.isEmpty(oldTrades) && !ObjectUtils.isEmpty(user))
		{
			user.setId(id);
			return saveTrades(user);
		}			
		return null;
	}

	@Override
	public void deleteTrades(Integer id)
	{
		if(tradesRepository.existsById(id))
			tradesRepository.deleteById(id);
		else
			throw new ResourceNotFoundException("Trades", "id", id);
	}
}
